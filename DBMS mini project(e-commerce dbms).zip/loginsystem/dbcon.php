<?php
$_SERVER ="localhost";
$USER ="root";
$PASSWORD ="";
$DB ="zipper_db";
$con = mysqli_connect($_SERVER,$USER,$PASSWORD,$DB);
// if($con){
//     ?>
     <script>
//         alert("connected sucessfully");
//     </script>
 <?php
// }else{
//     ?>
     <script>
//         alert("not connected sucessfully");
//     </script>
 <?php
// }
?>