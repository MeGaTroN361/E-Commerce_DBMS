-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2022 at 06:20 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zipper_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Cart_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Cart_id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18);

-- --------------------------------------------------------

--
-- Table structure for table `cart_item`
--

CREATE TABLE `cart_item` (
  `Cart_id` int(11) NOT NULL,
  `Product_id` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Purchase` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart_item`
--

INSERT INTO `cart_item` (`Cart_id`, `Product_id`, `Quantity`, `Date`, `Purchase`) VALUES
(10, 1, 1, '2022-01-27', 'yes'),
(10, 2, 1, '2022-01-27', 'yes'),
(10, 3, 1, '2022-01-28', 'yes'),
(10, 4, 2, '2022-01-28', 'yes'),
(10, 1, 1, '2022-01-28', 'yes'),
(12, 1, 1, '2022-01-28', 'yes'),
(13, 1, 1, '2022-01-31', 'yes'),
(13, 3, 1, '2022-01-31', 'yes'),
(13, 1, 1, '2022-01-31', 'no'),
(17, 1, 1, '2022-02-06', 'no'),
(17, 3, 1, '2022-02-06', 'no'),
(17, 4, 1, '2022-02-06', 'no'),
(16, 2, 2, '2022-03-21', 'Yes'),
(16, 1, 1, '2022-03-21', 'Yes'),
(16, 6, 1, '2022-03-21', 'Yes'),
(16, 1, 1, '2022-03-21', 'Yes'),
(16, 2, 1, '2022-03-21', 'Yes'),
(16, 4, 1, '2022-03-21', 'Yes'),
(18, 1, 1, '2022-03-21', 'Yes'),
(18, 3, 1, '2022-03-21', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Name` varchar(50) NOT NULL,
  `Address` varchar(150) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone_no` varchar(10) NOT NULL,
  `Pincode` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `C_pass` varchar(20) NOT NULL,
  `Confim_pass` varchar(20) NOT NULL,
  `Customer_id` int(11) NOT NULL,
  `Longitude` varchar(255) NOT NULL,
  `Latitude` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Name`, `Address`, `Email`, `Phone_no`, `Pincode`, `cart_id`, `C_pass`, `Confim_pass`, `Customer_id`, `Longitude`, `Latitude`) VALUES
('roshan', 'mysore', 'roshankeshav3@gmail.com', '9538775625', 5625, 16, 'Roshank', 'Roshank', 20, '', ''),
('Roshan', '12345', '123@gmail.com', '9898989898', 570010, 17, '12345678', '12345678', 21, '', ''),
('Roshan K', '#1122,bhavani street,ittigegudu', '1234@gmail.com', '9538775625', 570010, 18, '12345678', '12345678', 22, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `Payment_id` int(11) NOT NULL,
  `Payment_type` varchar(10) NOT NULL,
  `Payment_date` date NOT NULL,
  `Amount` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`Payment_id`, `Payment_type`, `Payment_date`, `Amount`, `cart_id`) VALUES
(2, 'COD', '2022-03-21', 30000, 10),
(5, 'COD', '2022-03-21', 166899, 16),
(6, 'UPI', '2022-03-21', 91900, 18);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_id` int(11) NOT NULL,
  `Seller_id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `Discount` float NOT NULL,
  `Description` varchar(150) NOT NULL,
  `Category` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_id`, `Seller_id`, `Name`, `Image`, `price`, `Discount`, `Description`, `Category`) VALUES
(1, 14, 'boat rock', 'boat rockerz 550.jpg', 10000, 10, 'boAt Rockerz 550 Bluetooth Wireless Over Ear Headphone with Mic (Black)', 'headphones'),
(2, 14, 'Samsung galaxy', 'samsung galaxy.jpg', 74999, 51, 'Samsung Galaxy S20 FE 5G (Cloud Navy, 8GB RAM, 128GB Storage) with No Cost EMI & Additional Exchange Offers', 'Phone'),
(3, 14, 'hp pavilion', 'hp pavilion.jpg', 81900, 12, 'HP Pavilion Gaming 10th Gen Intel Core i5 Processor 39.62 cm (15.6-inch) FHD Gaming Laptop (8GB/512GB SSD + 32GB Intel Optane/144 Hz/Win10/MS Office/N', 'Laptop'),
(4, 14, 'asus', 'asus.jpg', 81900, 30, 'ASUS TUF Gaming F15 Laptop 15.6\" (39.62 cms) FHD 144Hz, Intel Core i5-10300H 10th Gen, GeForce GTX 1650 4GB GDDR6 Graphics (8GB RAM/512GB NVMe SSD/Win', 'Laptop'),
(5, 14, 'Realme 8', 'realme 8.jpg', 15000, 10, 'realme 8 (Cyber Black, 4GB RAM, 128GB Storage) with No Cost EMI/Additional Exchange Offers', 'Phone'),
(6, 14, 'sony headbass', 'sony wh-ch710n.jpg', 15000, 15, 'Sony WH-CH710N Noise Cancelling Wireless Headphones : Bluetooth Over The Ear Headset with Mic for Phone-Call, 35 Hours Battery Life, Quick Charge and ', 'headphones'),
(9, 14, 'jbl 410t', 'jbl 410t.jpg', 3000, 10, 'jbl is the best ,jbl made by harman music world..', 'headphones');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `Seller_id` int(11) NOT NULL,
  `Address` varchar(150) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Spass` varchar(20) NOT NULL,
  `confirm_spass` varchar(20) NOT NULL,
  `Phone_no` varchar(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `pincode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`Seller_id`, `Address`, `Name`, `Spass`, `confirm_spass`, `Phone_no`, `Email`, `pincode`) VALUES
(14, '#1122,bhavani street,ittigegud,mysore-10.', 'Roshan', '12345678', '12345678', '6363667453', 'roshankeshav3@gmail.com', 570010);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Cart_id`);

--
-- Indexes for table `cart_item`
--
ALTER TABLE `cart_item`
  ADD KEY `cart_id` (`Cart_id`),
  ADD KEY `Product_id` (`Product_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`),
  ADD KEY `cart_id` (`cart_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`Payment_id`),
  ADD KEY `cart_id` (`cart_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_id`),
  ADD KEY `Seller_id` (`Seller_id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`Seller_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `Cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `Payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `Seller_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_item`
--
ALTER TABLE `cart_item`
  ADD CONSTRAINT `cart_item_ibfk_1` FOREIGN KEY (`Cart_id`) REFERENCES `cart` (`Cart_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_item_ibfk_2` FOREIGN KEY (`Product_id`) REFERENCES `product` (`Product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`Cart_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`Cart_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
